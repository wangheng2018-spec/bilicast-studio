﻿# BiliCast Studio

> 把 B 站视频整理成带时间轴的 PDF 笔记

提交 Bilibili 视频链接，网站自动嵌入播放器、读取字幕（或用本地语音识别生成字幕）、按时间段整理内容，并导出为 PDF 文档。

## 功能

- **站内播放** — 页面直接嵌入 Bilibili 播放器，边看视频边看报告
- **字幕读取** — 自动读取 Bilibili 公开字幕或 AI 字幕
- **本地 ASR** — 没有字幕的视频，下载音频后用 faster-whisper 语音识别
- **时间轴报告** — 按时间段整理内容，显示标题、摘要、要点
- **PDF 导出** — 一键下载带时间轴的播客式 PDF 笔记

## 快速开始

### 安装依赖

`ash
# 基础依赖（必须）
pip install reportlab

# 本地 ASR 依赖（可选，给没有字幕的视频使用）
pip install yt-dlp faster-whisper

# FFmpeg（本地 ASR 需要）
# Windows:
winget install ffmpeg
# 或从 https://ffmpeg.org/download.html 下载并添加到 PATH

# macOS:
brew install ffmpeg

# Linux:
sudo apt install ffmpeg
`

### 启动

`ash
python server.py --host 127.0.0.1 --port 8000
`

然后浏览器打开 http://127.0.0.1:8000

Windows 也可以双击 un_bilicast_server.bat。

## 文件结构

`
bilicast-studio/
├── server.py              # Python 后端（纯标准库，无框架依赖）
├── index.html             # 前端页面
├── styles.css             # 响应式样式
├── app.js                 # 前端交互
├── requirements.txt       # Python 依赖
├── run_bilicast_server.bat # Windows 启动脚本
└── README.md
`

## 识别模式

| 模式 | 说明 | 依赖 |
|---|---|---|
| **读取B站字幕** | 通过 Bilibili API 读取公开字幕或 AI 字幕 | 无 |
| **本地 ASR 识别** | 下载音频后用 faster-whisper 语音识别 | yt-dlp, faster-whisper, ffmpeg |
| **本地演示** | 不联网，生成示例报告用于测试流程 | 无 |

## API

### POST /api/analyze

请求：
`json
{
  "url": "https://www.bilibili.com/video/BV...",
  "mode": "subtitle",
  "page": 1,
  "reportTitle": "可选标题"
}
`

mode 可选值：subtitle（B站字幕）、sr（本地识别）、demo（演示）

返回：
`json
{
  "source": "bilibili-subtitle",
  "title": "视频标题",
  "duration": "18:42",
  "summary": "整体摘要",
  "keywords": ["关键词"],
  "segments": [
    {
      "start": "00:00",
      "end": "02:15",
      "title": "段落标题",
      "summary": "内容摘要",
      "highlights": ["要点一", "要点二"]
    }
  ]
}
`

### POST /api/report.pdf

传入上面的 report JSON，返回 PDF 文件。

## 技术栈

- **后端** — Python 标准库（http.server），零框架依赖
- **前端** — 纯 HTML / CSS / JavaScript
- **PDF** — reportlab
- **ASR** — faster-whisper
- **视频信息** — Bilibili 开放 API
